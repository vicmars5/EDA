#include "menu.h"

#include <string>

#include "list.h"
#include "song.h"
#include "node.h"
#include "menu.h"

using namespace std;

int main() {
    /*
    List<int> songs;
    int n = 1;
    songs.insertData(songs.getLastPos(), n);*/

    Menu m;
    m.showMenu();
    return 0;
}

