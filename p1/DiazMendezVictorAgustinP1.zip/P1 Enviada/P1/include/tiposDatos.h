#ifndef TIPOSDATOS_H
#define TIPOSDATOS_H


class TiposDatos
{
    public:
        TiposDatos();
        virtual ~TiposDatos();
        void mostrarTiposDatos();
    protected:
    private:
};

#endif // TIPOSDATOS_H
