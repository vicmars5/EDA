#ifndef SONG_H
#define SONG_H

#include <string>

using namespace std;

struct Song {
public:
    int ranking;
    string name;
    string author;
    string player;
};

#endif // SONG_H
