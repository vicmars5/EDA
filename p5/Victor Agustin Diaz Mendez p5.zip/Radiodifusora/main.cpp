#include "menu.h"

int main() {
    Menu menu;
    menu.showMenu();
    return 0;
}

