#include "menu.h"

#include <string>

#include "list.h"
#include "song.h"
#include "node.h"
#include "menu.h"

using namespace std;

int main() {

    Menu m;
    m.showMenu();
    return 0;
}

